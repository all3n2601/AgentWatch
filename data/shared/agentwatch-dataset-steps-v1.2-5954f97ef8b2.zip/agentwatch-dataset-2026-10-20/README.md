# AgentWatch step dataset — 2026-10-20 collection

One measured, gated dataset release built from fresh real runs, for building and testing the
Airflow DAG (collect → extract → validate → build → split → version) and other pipeline work.
No synthetic or replayed rows; every run recorded in the collection is included, pass or
inconclusive.

| | |
|---|---|
| Release | `steps-v1.2+5954f97ef8b2` (schema `steps-v1.2`, labels `labels-v1.1+fd085fa4`, release format 2) |
| Rows | 350 steps from 50 runs (25 CPU, 25 coding), 2 tasks |
| Labels | `none` 300, `cpu_sandbox` 50 |
| Conditions | `baseline` 250, `clean` 50, `contended` 50 |
| Quality gate | **passed** — TFDV 1.21.0, 0 anomalies, frozen schema `pipelines/validation/schema/steps.pbtxt` |
| Split | frozen (`split-v1+58e921fa846a`), but **blocked by the leakage check** — see Limitations |
| Parquet SHA-256 | `725290155c8e710d1aeb5c2c27b710c7e7f7dd9ebf65c46f7a5c367955267f0b` |
| Reproducible | Rebuilding `data/evidence/` with the same code reproduced `steps.parquet`, `schema.json` and `manifest.json` byte for byte |
| Code | AgentWatch `main` at `30f998a` (worker, data pipeline and gate unmodified) |

## Layout

The archive mirrors the repository, so unzip it at the repo root:

```
data/evidence/<kind>-<run_id>/            curated evidence: results.json + samples.jsonl (50 runs)
data/datasets/steps-v1.2+5954f97ef8b2/    steps.parquet, schema.json, manifest.json
data/datasets/builds/                      build report (sources, counts, rejections: 0)
data/datasets/validations/<release>/       gate result.json + TFDV statistics.pbtxt
data/datasets/splits/<release>/            frozen split with leakage report
raw/collection-20261020/                   everything the collection wrote (see below)
SHA256SUMS                                 checksums of every file in this archive
```

`data/` is not tracked by Git and the DVC remote does not exist yet, so this archive is the
shared copy. Do not commit `data/*.dvc` pointers until the team bucket exists
(docs/data-pipeline-plan.md, platform task F).

## Using it with the repo

From the repo root after unzipping (Python steps need Linux or WSL; see docs/data-card.md):

```sh
make dataset                 # rebuilds from data/evidence -> same version, reuses the release
make validate-dataset        # TFDV gate (CPython 3.13, glibc >= 2.39, a C++ compiler for pyfarmhash)
make split-dataset           # re-freezes the split; reports the same leakage block
```

Pipeline code should select releases with `published_releases()` in
`pipelines/data/src/agentwatch_data/build.py` rather than globbing directories. Column
contracts are in `schema.json` and documented in `docs/data-card.md` (Column roles); 40
columns with roles `id`, `feature`, `label`, `rule`, `lineage`. Nulls mean "not measured", never
zero — for example `cgroup_throttled_usec_delta` is null in 186 rows and `telemetry_coverage`
in 143 because short steps got 0–1 samples.

## How it was collected

- **Host:** Windows 11 laptop, WSL2 Ubuntu (kernel 6.18.54.1-microsoft-standard-WSL2), 16
  logical CPUs, PSI and cgroup v2 available. Ingestion API in WSL, PostgreSQL in
  Docker Desktop. Run window 2026-10-21 00:54:49–01:00:55 UTC.
- **Experiments:** `python -m agentwatch_worker.demo` (CPU: fixed SHA-256 task; coding: fixed
  Python project running three tests), worker capacity 1, 5 clean baseline repeats, then a clean
  run and a contended run where 8× competing work holds the single worker. CPU and coding runs
  were interleaved (cpu-r01, coding-r01, cpu-r02, …) so background noise hits both kinds alike.
  Nothing was rerun or dropped.
- **Outcomes:** CPU 22 passed / 3 inconclusive; coding 16 passed / 9 inconclusive. Every
  inconclusive run failed only `stable_baseline` (baseline execution CV ≥ 15%; CPU CV median
  9.2%, max 19.1%; coding median 12.6%, max 32.6%). Queue attribution was consistent in all
  50: clean queue ≤ 0.0011 s, contended 1.24–1.79 s. Seven clean runs exceeded the noise
  threshold (`label_basis = clean_exceeded_noise`).

## GPU agent runs (raw only, not in the Parquet)

`raw/collection-20261020/agent/gpu-agent-r1..r5/` holds five runs of the instrumented agent
(`services/agent`, task `fix-mean-empty`, Qwen3 1.7B Q4_K_M in Docker Ollama on an RTX 5070
Laptop GPU, 8 GiB). All five completed and passed the task; Ollama reported the model 100% in
VRAM for every call. Each directory has `agent-runs/*/agent-evidence.json` and
`live-journal.jsonl` (the live StepEvent/resource-sample records), plus `gpu-samples.csv` from
an `nvidia-smi` diagnostic at a 250 ms target (achieved median 268–273 ms, no gaps; whole-run
GPU utilization mean 17–19%, peak 88–98%; power peak 26–32 W) and `probe-meta.txt` with the
sampler's UTC offset.

The dataset builder does not read agent-runner evidence yet, and the GPU samples are a
diagnostic, not AgentWatch telemetry (the GPU sampler, A04, is not built). Use them for
exploration and DAG plumbing, not as labeled data.

## Limitations — read before modelling

- **Not usable for model evaluation.** There are only two tasks, so the grouped split puts the
  whole CPU task in train (175 rows) and the whole coding task in test (175 rows), with an empty
  validation split. The leakage check is **blocked**: six features separate the classes with
  AUC > 0.98 (`queue_seconds`, `queue_fraction`, `duration_seconds`, `telemetry_sample_count`,
  `cgroup_available`, `cgroup_throttled_usec_delta`), because the only injected contention
  directly creates queue waiting. `label_resource` equals `rule_prediction` throughout.
- **Two classes only.** No `inference` or `retrieval` contention exists yet, so `cpu_sandbox`
  vs `none` is all this release can show.
- **`recorded_at` is null in all rows.** Local evidence carries no saved-at time; only the API
  source supplies one.
- **Baseline noise on this laptop** is high (12 of 50 runs inconclusive). This is recorded, not
  filtered; Windows background activity is a hypothesis, not an established cause.
- `task_id` is still the interim `kind:workload:iterations` placeholder.
- Raw logs under `raw/` contain local paths (`/mnt/c/Users/benoy/...`). The agent evidence
  contains the fixed task's prompts and code (a trusted fixture), no secrets.
